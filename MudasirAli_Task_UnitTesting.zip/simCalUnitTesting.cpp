#include<iostream>
#include<gtest/gtest.h>
using namespace std;
TEST(Addition,test1){
ASSERT_TRUE(-1+1==0);
}
TEST(Substraction,test2){
ASSERT_TRUE(-1-2==-3);
}
TEST(Multiplication,test3){
ASSERT_TRUE(1*2==2);
}
TEST(Division,test4){
ASSERT_TRUE(2/2==1);
}
TEST(Remainder,test5){
ASSERT_TRUE(10%2==0);
}
int main(){
testing::InitGoogleTest();
return RUN_ALL_TESTS();
}
