#include <iostream>
using namespace std;
void Fun() {
    int num1 , num2 , sum, sub, mul, div, rem;
    cout << " Enter the num1 :";
    cin >> num1;
    cout << " Enter the num2 :";
    cin >> num2;
    sum = num1 + num2;
    sub = num1 - num2;
    mul = num1 * num2;
    div = num1 / num2;
    rem = num1 % num2;
    cout << sum << endl;
    cout << sub <<endl;
    cout <<mul<<endl;
    cout << div << endl;
    cout << rem << endl;
}
int main()
{
    Fun();
}
